<meta http-equiv='refresh' content='0; url='<?php echo wp_logout_url(); ?>'> 
