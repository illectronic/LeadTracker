<?php
# FileName="Connection_php_mysql.htm"
# Type="MYSQL"
# HTTP="true"
$hostname_public = "localhost";
$database_public = "webprod";
$username_public = "donna";
$password_public = "donna324";
$public = mysql_connect($hostname_public, $username_public, $password_public) or trigger_error(mysql_error(),E_USER_ERROR);

//mysql_select_db("webdev", $public); 
mysql_select_db( $database_public, $public); 
?>
