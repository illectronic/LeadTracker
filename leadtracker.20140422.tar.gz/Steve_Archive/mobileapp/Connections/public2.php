<?php


$USER_ORA     = 'timesheets';
$PASSWORD_ORA = 'timeshit01';
$DATABASE_ORA = 'officedb';

$public_conn = oci_connect($USER_ORA, $PASSWORD_ORA, $DATABASE_ORA);
if (!$public_conn) {
    $e = oci_error();
    //trigger_error(htmlentities($e['message'], ENT_QUOTES), E_USER_ERROR);
}


?>
