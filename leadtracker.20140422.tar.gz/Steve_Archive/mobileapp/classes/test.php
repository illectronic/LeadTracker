<?php
 echo md5('p0rtal123') . "\n";

?>
