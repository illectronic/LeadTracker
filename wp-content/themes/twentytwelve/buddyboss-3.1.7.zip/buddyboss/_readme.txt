/*--------------------------------------------------------------
BUDDYBOSS THEME INFO
--------------------------------------------------------------*/

After activating the BuddyPress plugin, move this entire folder to the root level of "/wp-content/themes/".
Make sure this folder is just called "buddyboss".
Then activate the theme via Appearance > Themes.
Theme settings will be in Appearance > BuddyBoss.

Instructions: http://www.buddyboss.com/tutorials/
Support: http://www.buddyboss.com/support-forums/
Release Notes: http://www.buddyboss.com/release-notes/

Enjoy!