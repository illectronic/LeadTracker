
    <header class="entry-header">
      <h1 class="entry-title">
        <?php buddyboss_bp_legacy_title(); ?>
      </h1>
    </header>
